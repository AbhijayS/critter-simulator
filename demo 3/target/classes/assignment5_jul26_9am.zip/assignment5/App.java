package assignment5;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Border;
import javafx.scene.layout.BorderStroke;
import javafx.scene.layout.BorderStrokeStyle;
import javafx.scene.layout.BorderWidths;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.RowConstraints;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.LinkedList;
import java.util.Scanner;

import assignment5.Critter.CritterShape;

/**
 * JavaFX App
 */
public class App extends Application {

    private static Scene scene;
    public static double GRID_MAX_HEIGHT = 600;
    public static double GRID_MAX_WIDTH = 600;
    public static Image circleImage;
    public static Image squareImage;
    public static Image triangleImage;
    public static Image diamondImage;
    public static Image starImage;

    public static Image getImage(CritterShape critterShape) {
        switch(critterShape) {
            case CIRCLE: return circleImage;
            case SQUARE: return squareImage;
            case TRIANGLE: return triangleImage;
            case DIAMOND: return diamondImage;
            case STAR: return starImage;
            default: return null;
        }
    }
    
    @Override
    public void start(Stage stage) throws IOException {
        StackPane root = new StackPane();
        scene = new Scene(root, 1280, 720);
        stage.setScene(scene);

        Border simpleBorder = new Border(new BorderStroke(
            Color.BLACK,
            BorderStrokeStyle.SOLID,
            CornerRadii.EMPTY,
            new BorderWidths(1)));


        GridPane grid = new GridPane();
        grid.setPrefSize(GRID_MAX_WIDTH, GRID_MAX_HEIGHT);
        grid.setMaxSize(GRID_MAX_WIDTH, GRID_MAX_HEIGHT);
        grid.setBorder(simpleBorder);
        grid.setHgap(0);
        grid.setVgap(0);
        grid.setAlignment(Pos.TOP_LEFT);

        int COLS = Params.WORLD_WIDTH;
        int ROWS = Params.WORLD_HEIGHT;

        double maxCellWidth = App.GRID_MAX_WIDTH/COLS;
        double maxCellHeight = App.GRID_MAX_HEIGHT/ROWS;
        double maxImgWidth = Math.min(maxCellWidth,maxCellHeight)-3;
        double maxImgHeight = maxImgWidth;

        // download images
        circleImage = new Image("https://webstockreview.net/images/circle-vector-png-2.png", maxImgWidth, maxImgHeight, false, false, false);
        squareImage = new Image("https://www.freeiconspng.com/uploads/red-square-png-14.png", maxImgWidth, maxImgHeight, false, false, false);
        triangleImage = new Image("https://pngimg.com/uploads/triangle/triangle_PNG17.png", maxImgWidth, maxImgHeight, false, false, false);
        diamondImage = new Image("https://images.onlinelabels.com/images/clip-art/Graveman/Rhombus%20section%20marker-193077.png", maxImgWidth, maxImgHeight, false, false, false);
        starImage = new Image("https://upload.wikimedia.org/wikipedia/commons/thumb/e/e5/Full_Star_Yellow.svg/1200px-Full_Star_Yellow.svg.png", maxImgWidth, maxImgHeight, false, false, false);

        for (int x = 0; x < COLS; x++) {
            for (int y = 0; y < ROWS; y++) {
                StackPane cell = new StackPane();
    
                cell.setPrefSize(maxCellWidth, maxCellHeight);
                cell.setMaxSize(maxCellWidth, maxCellHeight);
                cell.setBorder(simpleBorder);
                cell.setAlignment(Pos.CENTER);
                cell.setPadding(new Insets(0));
            }
        }
        root.getChildren().addAll(grid);
        stage.show();

        Thread thread = new Thread(new Runnable(){
            public void run(){
                Project4_Main.commandInterpreter(new Scanner(System.in), grid);
            }
        });
        thread.start();
    }

    static void setRoot(String fxml) throws IOException {
        scene.setRoot(loadFXML(fxml));
    }

    private static Parent loadFXML(String fxml) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(App.class.getResource(fxml + ".fxml"));
        return fxmlLoader.load();
    }

    public static void main(String[] args) {
        launch();
    }

}
